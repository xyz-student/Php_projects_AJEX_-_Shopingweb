<?php 

$conn = mysqli_connect("localhost","root","","test") or die("Connection Failed");

 ?>