<!-- FOOTER -->
  <div id="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2021 <a href="https://www.yahoobaba.net">YahooBaba</a></span>
            </div>
        </div>
    </div>
  </div>
  <!-- /FOOTER -->
  <script src="js/jquery-3.6.0.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
